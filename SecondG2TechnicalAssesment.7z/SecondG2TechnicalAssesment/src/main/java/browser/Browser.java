package browser;

import platform.Eshop;

public class Browser {
    public Eshop eshop;
    public Browser(){eshop =new Eshop();}
}
