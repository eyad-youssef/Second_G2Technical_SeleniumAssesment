package pages.subpages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pages.BasePage;

//import java.time.Duration;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.lang.Thread.sleep;

public class Products extends BasePage {

    private final By categoryTab = By.name(" Oppo ");
    private final By item = By.xpath("/html/body/vf-root/main/section[2]/vf-product-list-page/div[2]/div[2]/div[4]/vf-product-box-featured[2]/div");
    private final By blackColor = By.xpath("/html/body/vf-root/main/section[2]/vf-middleware/vf-product-details-page/div[2]/div/div/div[1]/div[3]/div[3]/div/div/button[1]");
    private final By blueColor = By.xpath("/html/body/vf-root/main/section[2]/vf-middleware/vf-product-details-page/div[2]/div/div/div[1]/div[3]/div[3]/div/div/button[2]");
    private final By addToCartButton = By.xpath("/html/body/vf-root/main/section[2]/vf-middleware/vf-product-details-page/div[2]/div/div/div[1]/div[3]/div[8]/button[1]");


    public void clickOnCategoryTab() {
        waitUntilElementIsClickable(categoryTab).click();


    }

    public void clickOnItem() {
        waitUntilElementIsClickable(item).click();


    }


    public void choose() {

        if (waitUntilElementIsClickable(blackColor).isSelected() && waitUntilElementIsClickable(addToCartButton).isEnabled()) {

            waitUntilElementIsClickable(addToCartButton).click();
        } else if (waitUntilElementIsClickable(blueColor).isSelected() && waitUntilElementIsClickable(addToCartButton).isEnabled()) {

            waitUntilElementIsClickable(addToCartButton).click();
        }


    }


}
