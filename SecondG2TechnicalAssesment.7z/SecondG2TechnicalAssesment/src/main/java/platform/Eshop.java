package platform;

import pages.HomePage;
import pages.LoginPage;
import pages.subpages.Products;

public class Eshop {
    public LoginPage login;
    public HomePage home;
    public Products products;


    public Eshop(){
        login = new LoginPage();
    }
}
