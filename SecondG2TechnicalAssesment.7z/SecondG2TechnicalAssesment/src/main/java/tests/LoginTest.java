package tests;

import org.testng.annotations.Test;

public class LoginTest extends BaseTest {

    @Test (priority = 1)
    public void login() throws InterruptedException {
        webDriver.navigateTo("https://eshop.vodafone.com.eg/en");
        browser.eshop.login.clickOnLoginButton();
        browser.eshop.login.enterUsername("01030122389");
        browser.eshop.login.enterPassword("Test@2023");
        Thread.sleep(100);
        browser.eshop.login.clickOnSubmitButton();


    }
    @Test (priority = 2)
    public void search(){
        browser.eshop.home= browser.eshop.login.goHome();
        browser.eshop.home.enterSearchItem("samsung");
        browser.eshop.home.clickOnSearchResult();
    }
    @Test(priority = 3)
 public  void getItem(){

     browser.eshop.products = browser.eshop.home.goToProducts();
     browser.eshop.products.clickOnCategoryTab();
     browser.eshop.products.clickOnItem();
     browser.eshop.products.waitUntilAlertIsPresent();


    }
}
